# Как опубликовать на GitHub

1. Открой https://github.com/new и создай **Public** репозиторий `wazuh-soc-homelab`.
2. Не добавляй README при создании репозитория: готовый README уже находится в папке проекта.
3. Распакуй ZIP на своём компьютере.
4. Открой репозиторий -> **Add file** -> **Upload files** (или **uploading an existing file**).
5. Перетащи **всё содержимое папки** `wazuh-soc-homelab` (README.md, папки screenshots, detection-rules, incident-reports), не сам ZIP.
6. Введи сообщение коммита `Add Wazuh SOC homelab documentation and detection evidence` и нажми **Commit changes**.
7. Открой README на GitHub и проверь, что ссылки на скриншоты работают.
8. При желании добавь ссылку в резюме в раздел Projects.

Важно: убедись, что в скриншотах нет приватных ключей, паролей, токенов или личной информации, которую не хочешь публиковать. XML — пример по пройденным шагам, а не экспорт фактического файла с сервера.
